package com.example.bookapi.service;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import com.example.bookapi.model.Book;
import com.example.bookapi.repository.BookRepository;
import com.example.bookapi.exception.ResourceNotFoundException;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository repository;
    @Autowired
    public BookServiceImpl(BookRepository repository) { this.repository = repository; }

    @Override
    public List<Book> getAllBooks() { return repository.findAll(); }

    @Override
    public Book getBookById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));
    }

    @Override
    public Book createBook(Book book) { return repository.save(book); }

    @Override
    public Book updateBook(Long id, Book bookDetails) {
        Book existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));
        existing.setTitle(bookDetails.getTitle());
        existing.setAuthor(bookDetails.getAuthor());
        existing.setPublishedYear(bookDetails.getPublishedYear());
        existing.setGenre(bookDetails.getGenre());
        return repository.save(existing);
    }

    @Override
    public void deleteBook(Long id) {
        Book existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));
        repository.delete(existing);
    }
}