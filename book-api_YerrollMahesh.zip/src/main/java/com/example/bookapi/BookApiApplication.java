package com.example.bookapi;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.CommandLineRunner;
import com.example.bookapi.repository.BookRepository;
import com.example.bookapi.model.Book;

@SpringBootApplication
public class BookApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookApiApplication.class, args);
    }

    @Bean
    CommandLineRunner initData(BookRepository repo) {
        return args -> {
            repo.save(new Book(null, "Clean Code", "Yerroll Mahesh", 2008, "Programming"));
            repo.save(new Book(null, "The Pragmatic Programmer", "Yerroll Mahesh", 1999, "Programming"));
        };
    }
}